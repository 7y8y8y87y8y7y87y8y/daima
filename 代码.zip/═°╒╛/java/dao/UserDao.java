package dao;

import model.User;
import utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
    //添加用户
    public boolean insert(User user){
        Connection conn=null;
        Statement stmt=null;
        try{
            conn= JDBCUtils.getConnection();
            stmt=conn.createStatement();
            String sql="insert into zb_user(id,name) values ("+user.getId()+",'"+user.getName()+"')";
            int num=stmt.executeUpdate(sql);
            if (num>0){
                return true;
            }
            return false;
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }
    //查询用户
    public List<User> select(){
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        ArrayList<User> users = new ArrayList<>();
        try{
            conn= JDBCUtils.getConnection();
            String sql="select * from zb_user ";
            stmt=conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()){
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                users.add(user);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return users;
    }
}
